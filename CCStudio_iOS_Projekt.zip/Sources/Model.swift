import SwiftUI
import PhotosUI
import Photos
import CoreImage
import UniformTypeIdentifiers

/// Damit PhotosPicker ein Video als Datei liefern kann
struct VideoFile: Transferable {
    let url: URL

    static var transferRepresentation: some TransferRepresentation {
        FileRepresentation(contentType: .movie) { video in
            SentTransferredFile(video.url)
        } importing: { received in
            let ext = received.file.pathExtension.isEmpty ? "mov" : received.file.pathExtension
            let dest = FileManager.default.temporaryDirectory
                .appendingPathComponent("in_\(UUID().uuidString).\(ext)")
            try FileManager.default.copyItem(at: received.file, to: dest)
            return VideoFile(url: dest)
        }
    }
}

@MainActor
final class CCModel: ObservableObject {
    // Video
    @Published var videoURL: URL?
    @Published var previewImage: UIImage?
    @Published var showAfter: Bool = true

    // LUTs
    @Published var luts: [URL] = []
    @Published var selectedLUT: URL?

    // Einstellungen
    @Published var strength: Double = 1.0
    @Published var neutral: Double = 0.0
    @Published var hueLimit: Double = 0.0
    @Published var fixBlack: Bool = false
    @Published var brightness: Double = 0.0
    @Published var contrast: Double = 1.0
    @Published var saturation: Double = 1.0

    // Export
    @Published var rendering: Bool = false
    @Published var progress: Float = 0
    @Published var resultURL: URL?
    @Published var savedToPhotos: Bool = false
    @Published var message: String = ""

    private var previewSource: CGImage?
    private var baseLUT: CubeLUT?
    private var spec = FilterSpec()
    private var cubeKey = ""
    private let ciContext = CIContext()

    var settingsKey: String {
        let lut = selectedLUT?.lastPathComponent ?? "-"
        return "\(lut)|\(strength)|\(neutral)|\(hueLimit)|\(fixBlack)|\(brightness)|\(contrast)|\(saturation)|\(showAfter)"
    }

    var lutDirectory: URL {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let dir = docs.appendingPathComponent("LUTs", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir
    }

    init() {
        refreshLUTList()
    }

    // MARK: LUTs

    func refreshLUTList() {
        let files = (try? FileManager.default.contentsOfDirectory(at: lutDirectory, includingPropertiesForKeys: nil)) ?? []
        luts = files.filter { $0.pathExtension.lowercased() == "cube" }
            .sorted { $0.lastPathComponent.lowercased() < $1.lastPathComponent.lowercased() }
    }

    func importLUT(from url: URL) {
        let access = url.startAccessingSecurityScopedResource()
        defer { if access { url.stopAccessingSecurityScopedResource() } }
        do {
            let text = try String(contentsOf: url, encoding: .utf8)
            _ = try CubeLUT.parse(text)           // nur prüfen
            let dest = lutDirectory.appendingPathComponent(url.lastPathComponent)
            try? FileManager.default.removeItem(at: dest)
            try text.write(to: dest, atomically: true, encoding: .utf8)
            refreshLUTList()
            selectLUT(dest)
            message = "LUT geladen: \(url.lastPathComponent)"
        } catch {
            message = error.localizedDescription
        }
    }

    func selectLUT(_ url: URL?) {
        selectedLUT = url
        cubeKey = ""
        guard let url = url else {
            baseLUT = nil
            refresh()
            return
        }
        do {
            let text = try String(contentsOf: url, encoding: .utf8)
            baseLUT = try CubeLUT.parse(text)
        } catch {
            baseLUT = nil
            message = error.localizedDescription
        }
        refresh()
    }

    func deleteLUT(_ url: URL) {
        try? FileManager.default.removeItem(at: url)
        if selectedLUT == url { selectLUT(nil) }
        refreshLUTList()
    }

    // MARK: Video

    func setVideo(_ url: URL) {
        videoURL = url
        resultURL = nil
        savedToPhotos = false
        Task {
            let frame = await VideoPipeline.previewFrame(url: url)
            self.previewSource = frame
            if frame == nil { self.message = "Vorschau konnte nicht erstellt werden." }
            self.refresh()
        }
    }

    // MARK: Look berechnen

    private var corrections: Corrections {
        Corrections(strength: strength, neutral: neutral, hueLimit: hueLimit, fixBlack: fixBlack)
    }

    private func rebuildSpecIfNeeded() {
        let key = "\(selectedLUT?.lastPathComponent ?? "-")|\(strength)|\(neutral)|\(hueLimit)|\(fixBlack)"
        if key != cubeKey {
            cubeKey = key
            if let base = baseLUT {
                let fixed = base.corrected(corrections)
                spec.cubeSize = fixed.size
                spec.cubeData = fixed.ciCubeData()
            } else {
                spec.cubeSize = 0
                spec.cubeData = nil
            }
        }
        spec.brightness = brightness
        spec.contrast = contrast
        spec.saturation = saturation
    }

    func refresh() {
        guard let cg = previewSource else {
            previewImage = nil
            return
        }
        rebuildSpecIfNeeded()
        let source = CIImage(cgImage: cg)
        let output = showAfter ? spec.apply(source) : source
        if let result = ciContext.createCGImage(output, from: source.extent) {
            previewImage = UIImage(cgImage: result)
        }
    }

    // MARK: Export

    func render() {
        guard let url = videoURL, !rendering else { return }
        rebuildSpecIfNeeded()
        let currentSpec = spec
        rendering = true
        progress = 0
        resultURL = nil
        savedToPhotos = false
        message = ""
        Task {
            do {
                let out = try await VideoPipeline.export(url: url, spec: currentSpec) { value in
                    Task { @MainActor in self.progress = value }
                }
                self.resultURL = out
                self.message = "Fertig. Du kannst das Video jetzt speichern oder teilen."
            } catch {
                self.message = error.localizedDescription
            }
            self.rendering = false
        }
    }

    func saveToPhotos() {
        guard let url = resultURL else { return }
        Task {
            let status = await PHPhotoLibrary.requestAuthorization(for: .addOnly)
            guard status == .authorized || status == .limited else {
                self.message = "Kein Zugriff auf die Mediathek. Bitte in den iPhone-Einstellungen erlauben."
                return
            }
            do {
                try await PHPhotoLibrary.shared().performChanges {
                    PHAssetChangeRequest.creationRequestForAssetFromVideo(atFileURL: url)
                }
                self.savedToPhotos = true
                self.message = "In der Mediathek gespeichert."
            } catch {
                self.message = "Speichern fehlgeschlagen: \(error.localizedDescription)"
            }
        }
    }

    /// Die korrigierte LUT als .cube-Datei (zum Weitergeben an andere Apps)
    func correctedCubeFile() -> URL? {
        guard let base = baseLUT, let name = selectedLUT?.deletingPathExtension().lastPathComponent else { return nil }
        let fixed = base.corrected(corrections)
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("\(name)_korrigiert.cube")
        do {
            try fixed.cubeText(title: "\(name)_korrigiert").write(to: url, atomically: true, encoding: .utf8)
            return url
        } catch {
            return nil
        }
    }
}
