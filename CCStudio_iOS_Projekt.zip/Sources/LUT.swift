import Foundation

/// Einstellungen für die Korrekturen an einer LUT
struct Corrections: Equatable {
    var strength: Double = 1.0      // 0...1  (Ausgabe = x + (LUT(x) - x) * Stärke)
    var neutral: Double = 0.0       // 0...1  Graustich entfernen
    var hueLimit: Double = 0.0      // Grad, 0 = aus
    var fixBlack: Bool = false      // angehobenes/gefärbtes Schwarz entfernen
}

/// 3D-LUT im .cube-Format (R wechselt am schnellsten)
struct CubeLUT {
    var size: Int
    var rgb: [Float]

    enum ParseError: LocalizedError {
        case notSupported1D
        case invalid
        var errorDescription: String? {
            switch self {
            case .notSupported1D: return "Das ist eine 1D-LUT. Bitte eine 3D-.cube verwenden."
            case .invalid: return "Die Datei ist keine gültige 3D-.cube."
            }
        }
    }

    static func parse(_ text: String) throws -> CubeLUT {
        var n = 0
        var vals: [Float] = []
        for line in text.components(separatedBy: .newlines) {
            let parts = line.split(whereSeparator: { $0 == " " || $0 == "\t" })
            guard let first = parts.first else { continue }
            if first.hasPrefix("#") { continue }
            if first == "LUT_3D_SIZE" {
                if parts.count > 1 { n = Int(parts[1]) ?? 0 }
                continue
            }
            if first == "LUT_1D_SIZE" { throw ParseError.notSupported1D }
            if parts.count >= 3, let r = Float(parts[0]), let g = Float(parts[1]), let b = Float(parts[2]) {
                vals.append(r)
                vals.append(g)
                vals.append(b)
            }
        }
        guard n >= 2, vals.count == n * n * n * 3 else { throw ParseError.invalid }
        return CubeLUT(size: n, rgb: vals)
    }

    // MARK: - Korrekturen

    func corrected(_ c: Corrections) -> CubeLUT {
        let n = size
        let count = n * n * n
        var out: [Double] = rgb.map { Double($0) }
        if c.fixBlack { CubeLUT.fixBlack(&out, n) }
        if c.neutral > 0 { CubeLUT.neutralize(&out, n, c.neutral) }
        if c.hueLimit > 0 { CubeLUT.limitHue(&out, n, c.hueLimit) }
        if c.strength < 0.999 {
            let d = Double(n - 1)
            for i in 0..<count {
                let ir = Double(i % n) / d
                let ig = Double((i / n) % n) / d
                let ib = Double(i / (n * n)) / d
                out[i * 3] = ir + (out[i * 3] - ir) * c.strength
                out[i * 3 + 1] = ig + (out[i * 3 + 1] - ig) * c.strength
                out[i * 3 + 2] = ib + (out[i * 3 + 2] - ib) * c.strength
            }
        }
        let result: [Float] = out.map { Float(min(max($0, 0), 1)) }
        return CubeLUT(size: n, rgb: result)
    }

    /// Schwarz soll Schwarz bleiben (Mitten und Lichter bleiben unberührt)
    private static func fixBlack(_ out: inout [Double], _ n: Int) {
        let b0 = [out[0], out[1], out[2]]
        let d = Double(n - 1)
        for i in 0..<(n * n * n) {
            let r = Double(i % n) / d
            let g = Double((i / n) % n) / d
            let b = Double(i / (n * n)) / d
            let y = 0.2126 * r + 0.7152 * g + 0.0722 * b
            let w = pow(1.0 - y, 3.0)
            for k in 0..<3 {
                let v = out[i * 3 + k] - b0[k] * w
                out[i * 3 + k] = min(max(v, 0), 1)
            }
        }
    }

    /// Farbstich auf der Grauachse entfernen (Helligkeit/Kontrast/Farben bleiben)
    private static func neutralize(_ out: inout [Double], _ n: Int, _ strength: Double) {
        var cast: [[Double]] = []
        for i in 0..<n {
            let idx = ((i * n + i) * n + i) * 3
            let r = out[idx]
            let g = out[idx + 1]
            let b = out[idx + 2]
            let m = (r + g + b) / 3.0
            cast.append([r - m, g - m, b - m])
        }
        for i in 0..<(n * n * n) {
            let r = Double(i % n)
            let g = Double((i / n) % n)
            let b = Double(i / (n * n))
            let y = 0.2126 * r + 0.7152 * g + 0.0722 * b
            let y0 = min(max(Int(floor(y)), 0), n - 2)
            let f = y - Double(y0)
            for k in 0..<3 {
                let c = cast[y0][k] * (1.0 - f) + cast[y0 + 1][k] * f
                let v = out[i * 3 + k] - strength * c
                out[i * 3 + k] = min(max(v, 0), 1)
            }
        }
    }

    // MARK: - OKLab

    private static func srgbToLinear(_ x: Double) -> Double {
        if x <= 0.04045 { return x / 12.92 }
        return pow((x + 0.055) / 1.055, 2.4)
    }

    private static func linearToSrgb(_ x: Double) -> Double {
        if x <= 0.0031308 { return x * 12.92 }
        return 1.055 * pow(x, 1.0 / 2.4) - 0.055
    }

    private static func toOKLab(_ r: Double, _ g: Double, _ b: Double) -> (Double, Double, Double) {
        let rl = srgbToLinear(min(max(r, 0), 1))
        let gl = srgbToLinear(min(max(g, 0), 1))
        let bl = srgbToLinear(min(max(b, 0), 1))
        let l0: Double = 0.4122214708 * rl + 0.5363325363 * gl + 0.0514459929 * bl
        let m0: Double = 0.2119034982 * rl + 0.6806995451 * gl + 0.1073969566 * bl
        let s0: Double = 0.0883024619 * rl + 0.2817188376 * gl + 0.6299787005 * bl
        let l = cbrt(l0)
        let m = cbrt(m0)
        let s = cbrt(s0)
        let L: Double = 0.2104542553 * l + 0.7936177850 * m - 0.0040720468 * s
        let a: Double = 1.9779984951 * l - 2.4285922050 * m + 0.4505937099 * s
        let bb: Double = 0.0259040371 * l + 0.7827717662 * m - 0.8086757660 * s
        return (L, a, bb)
    }

    private static func fromOKLab(_ L: Double, _ a: Double, _ b: Double) -> (Double, Double, Double) {
        let l1: Double = L + 0.3963377774 * a + 0.2158037573 * b
        let m1: Double = L - 0.1055613458 * a - 0.0638541728 * b
        let s1: Double = L - 0.0894841775 * a - 1.2914855480 * b
        let l = l1 * l1 * l1
        let m = m1 * m1 * m1
        let s = s1 * s1 * s1
        let r: Double = 4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s
        let g: Double = -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s
        let bl: Double = -0.0041960863 * l - 0.7034186147 * m + 1.7076147010 * s
        return (linearToSrgb(r), linearToSrgb(g), linearToSrgb(bl))
    }

    private static func inGamut(_ c: (Double, Double, Double)) -> Bool {
        let lo = -0.0001
        let hi = 1.0001
        return c.0 >= lo && c.0 <= hi && c.1 >= lo && c.1 <= hi && c.2 >= lo && c.2 <= hi
    }

    /// Begrenzt, wie weit die LUT Farbtöne drehen darf (verhindert z. B. grüne Haut)
    private static func limitHue(_ out: inout [Double], _ n: Int, _ maxDeg: Double) {
        let d = Double(n - 1)
        let m = maxDeg * Double.pi / 180.0
        for i in 0..<(n * n * n) {
            let r = Double(i % n) / d
            let g = Double((i / n) % n) / d
            let b = Double(i / (n * n)) / d
            let xi = toOKLab(r, g, b)
            let cx = hypot(xi.1, xi.2)
            if cx < 1e-6 { continue }
            let yr = out[i * 3]
            let yg = out[i * 3 + 1]
            let yb = out[i * 3 + 2]
            let yo = toOKLab(yr, yg, yb)
            let cy = hypot(yo.1, yo.2)
            let hx = atan2(xi.2, xi.1)
            let hy = atan2(yo.2, yo.1)
            var dh = (hy - hx + Double.pi).truncatingRemainder(dividingBy: 2.0 * Double.pi)
            if dh < 0 { dh += 2.0 * Double.pi }
            dh -= Double.pi
            let h2 = hx + m * tanh(dh / m)
            let L = min(max(yo.0, 0), 1)
            var t = 1.0
            let full = fromOKLab(L, cy * cos(h2), cy * sin(h2))
            var res = full
            if !inGamut(full) {
                var lo = 0.0
                var hi = 1.0
                for _ in 0..<14 {
                    let mid = (lo + hi) / 2.0
                    let c = fromOKLab(L, cy * mid * cos(h2), cy * mid * sin(h2))
                    if inGamut(c) { lo = mid } else { hi = mid }
                }
                t = lo
                res = fromOKLab(L, cy * t * cos(h2), cy * t * sin(h2))
            }
            let w = min(max(cx / 0.05, 0), 1)
            out[i * 3] = yr * (1.0 - w) + min(max(res.0, 0), 1) * w
            out[i * 3 + 1] = yg * (1.0 - w) + min(max(res.1, 0), 1) * w
            out[i * 3 + 2] = yb * (1.0 - w) + min(max(res.2, 0), 1) * w
        }
    }

    // MARK: - Ausgabe

    /// Daten für CIColorCube (RGBA, Float, R wechselt am schnellsten)
    func ciCubeData() -> Data {
        let count = size * size * size
        var floats = [Float](repeating: 1.0, count: count * 4)
        for i in 0..<count {
            floats[i * 4] = rgb[i * 3]
            floats[i * 4 + 1] = rgb[i * 3 + 1]
            floats[i * 4 + 2] = rgb[i * 3 + 2]
        }
        return floats.withUnsafeBufferPointer { Data(buffer: $0) }
    }

    /// .cube-Text zum Weitergeben an andere Apps
    func cubeText(title: String) -> String {
        var lines: [String] = []
        lines.reserveCapacity(size * size * size + 5)
        lines.append("TITLE \"\(title)\"")
        lines.append("LUT_3D_SIZE \(size)")
        lines.append("DOMAIN_MIN 0 0 0")
        lines.append("DOMAIN_MAX 1 1 1")
        let count = size * size * size
        for i in 0..<count {
            lines.append(String(format: "%.6f %.6f %.6f", rgb[i * 3], rgb[i * 3 + 1], rgb[i * 3 + 2]))
        }
        return lines.joined(separator: "\n") + "\n"
    }
}
