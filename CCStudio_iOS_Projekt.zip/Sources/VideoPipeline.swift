import Foundation
import AVFoundation
import CoreImage

/// Alles, was zum Anwenden des Looks nötig ist (reine Werte, daher gefahrlos im Hintergrund nutzbar)
struct FilterSpec {
    var cubeSize: Int = 0
    var cubeData: Data? = nil
    var brightness: Double = 0
    var contrast: Double = 1
    var saturation: Double = 1

    func apply(_ image: CIImage) -> CIImage {
        var out = image
        if let data = cubeData, cubeSize > 1, let space = CGColorSpace(name: CGColorSpace.sRGB) {
            let params: [String: Any] = [
                "inputImage": out,
                "inputCubeDimension": cubeSize,
                "inputCubeData": data,
                "inputColorSpace": space
            ]
            if let f = CIFilter(name: "CIColorCubeWithColorSpace", parameters: params), let o = f.outputImage {
                out = o
            }
        }
        if brightness != 0 || contrast != 1 || saturation != 1 {
            let params: [String: Any] = [
                kCIInputImageKey: out,
                kCIInputBrightnessKey: brightness,
                kCIInputContrastKey: contrast,
                kCIInputSaturationKey: saturation
            ]
            if let f = CIFilter(name: "CIColorControls", parameters: params), let o = f.outputImage {
                out = o
            }
        }
        return out
    }
}

enum ExportError: LocalizedError {
    case cannotCreate
    case failed(String)
    var errorDescription: String? {
        switch self {
        case .cannotCreate: return "Der Export konnte nicht gestartet werden."
        case .failed(let m): return "Der Export ist fehlgeschlagen: \(m)"
        }
    }
}

enum VideoPipeline {
    /// Rendert das Video mit dem Look. Der Ton bleibt erhalten.
    static func export(url: URL, spec: FilterSpec, progress: @escaping (Float) -> Void) async throws -> URL {
        let asset = AVURLAsset(url: url)
        let composition = AVMutableVideoComposition(asset: asset, applyingCIFiltersWithHandler: { request in
            let source = request.sourceImage.clampedToExtent()
            let result = spec.apply(source).cropped(to: request.sourceImage.extent)
            request.finish(with: result, context: nil)
        })

        let name = "CC_\(Int(Date().timeIntervalSince1970)).mov"
        let outURL = FileManager.default.temporaryDirectory.appendingPathComponent(name)
        try? FileManager.default.removeItem(at: outURL)

        let presets = AVAssetExportSession.exportPresets(compatibleWith: asset)
        let preset = presets.contains(AVAssetExportPresetHEVCHighestQuality)
            ? AVAssetExportPresetHEVCHighestQuality
            : AVAssetExportPresetHighestQuality
        guard let session = AVAssetExportSession(asset: asset, presetName: preset) else {
            throw ExportError.cannotCreate
        }
        session.videoComposition = composition
        session.outputURL = outURL
        session.outputFileType = .mov
        session.shouldOptimizeForNetworkUse = false

        session.exportAsynchronously { }
        while session.status == .waiting || session.status == .exporting {
            progress(session.progress)
            try await Task.sleep(nanoseconds: 200_000_000)
        }
        progress(1)
        if session.status != .completed {
            throw ExportError.failed(session.error?.localizedDescription ?? "unbekannter Fehler")
        }
        return outURL
    }

    /// Ein Standbild aus der Mitte des Videos für die Vorschau
    static func previewFrame(url: URL) async -> CGImage? {
        let asset = AVURLAsset(url: url)
        let generator = AVAssetImageGenerator(asset: asset)
        generator.appliesPreferredTrackTransform = true
        generator.maximumSize = CGSize(width: 1280, height: 1280)
        var seconds = 0.0
        if let duration = try? await asset.load(.duration) {
            seconds = max(duration.seconds / 2.0, 0)
        }
        let time = CMTime(seconds: seconds, preferredTimescale: 600)
        do {
            let result = try await generator.image(at: time)
            return result.image
        } catch {
            return nil
        }
    }
}
