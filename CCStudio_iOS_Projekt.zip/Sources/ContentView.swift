import SwiftUI
import PhotosUI
import UniformTypeIdentifiers

struct SliderRow: View {
    let title: String
    @Binding var value: Double
    let range: ClosedRange<Double>
    let format: String

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack {
                Text(title)
                Spacer()
                Text(String(format: format, value)).foregroundStyle(.secondary)
            }
            Slider(value: $value, in: range)
        }
    }
}

struct ContentView: View {
    @StateObject private var model = CCModel()
    @State private var pickerItem: PhotosPickerItem?
    @State private var importing = false
    @State private var cubeToShare: URL?

    var body: some View {
        NavigationStack {
            Form {
                Section("1 · Video") {
                    PhotosPicker(selection: $pickerItem, matching: .videos) {
                        Label(model.videoURL == nil ? "Video auswählen" : "Anderes Video wählen", systemImage: "video")
                    }
                    if let image = model.previewImage {
                        Image(uiImage: image)
                            .resizable()
                            .scaledToFit()
                            .cornerRadius(8)
                        Picker("Ansicht", selection: $model.showAfter) {
                            Text("Vorher").tag(false)
                            Text("Nachher").tag(true)
                        }
                        .pickerStyle(.segmented)
                    }
                }

                Section("2 · Look (.cube)") {
                    Button {
                        importing = true
                    } label: {
                        Label("Cube importieren", systemImage: "square.and.arrow.down")
                    }
                    if model.luts.isEmpty {
                        Text("Noch keine LUT. Importiere eine .cube-Datei aus „Dateien“.")
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                    }
                    ForEach(model.luts, id: \.self) { url in
                        Button {
                            model.selectLUT(url)
                        } label: {
                            HStack {
                                Text(url.deletingPathExtension().lastPathComponent)
                                Spacer()
                                if model.selectedLUT == url {
                                    Image(systemName: "checkmark.circle.fill")
                                }
                            }
                        }
                        .swipeActions {
                            Button(role: .destructive) {
                                model.deleteLUT(url)
                            } label: {
                                Label("Löschen", systemImage: "trash")
                            }
                        }
                    }
                }

                Section("3 · Korrektur") {
                    SliderRow(title: "Stärke", value: $model.strength, range: 0...1, format: "%.2f")
                    SliderRow(title: "Graustich entfernen", value: $model.neutral, range: 0...1, format: "%.2f")
                    SliderRow(title: "Farbton-Limit (0 = aus)", value: $model.hueLimit, range: 0...90, format: "%.0f°")
                    Toggle("Schwarz korrigieren", isOn: $model.fixBlack)
                    Text("Bei grüner oder gelber Haut: Farbton-Limit auf 20° und Stärke senken.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }

                Section("4 · Feinschliff") {
                    SliderRow(title: "Helligkeit", value: $model.brightness, range: -0.3...0.3, format: "%.2f")
                    SliderRow(title: "Kontrast", value: $model.contrast, range: 0.5...1.5, format: "%.2f")
                    SliderRow(title: "Sättigung", value: $model.saturation, range: 0...2, format: "%.2f")
                    Button("Zurücksetzen") {
                        model.brightness = 0
                        model.contrast = 1
                        model.saturation = 1
                        model.strength = 1
                        model.neutral = 0
                        model.hueLimit = 0
                        model.fixBlack = false
                    }
                }

                Section("5 · Export") {
                    Button {
                        model.render()
                    } label: {
                        Label("Video rendern", systemImage: "play.rectangle")
                    }
                    .disabled(model.videoURL == nil || model.rendering)

                    if model.rendering {
                        ProgressView(value: Double(model.progress))
                        Text("Rendert … \(Int(model.progress * 100)) %")
                            .font(.footnote)
                    }
                    if let result = model.resultURL {
                        Button {
                            model.saveToPhotos()
                        } label: {
                            Label(model.savedToPhotos ? "Gespeichert" : "In Mediathek sichern", systemImage: "photo")
                        }
                        ShareLink(item: result) {
                            Label("Video teilen", systemImage: "square.and.arrow.up")
                        }
                    }
                    if let cube = cubeToShare {
                        ShareLink(item: cube) {
                            Label("Korrigierte .cube teilen", systemImage: "square.and.arrow.up")
                        }
                    }
                    Button("Korrigierte .cube vorbereiten") {
                        cubeToShare = model.correctedCubeFile()
                    }
                    .disabled(model.selectedLUT == nil)
                    if !model.message.isEmpty {
                        Text(model.message)
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                    }
                }
            }
            .navigationTitle("CC Studio")
        }
        .fileImporter(
            isPresented: $importing,
            allowedContentTypes: [UTType(filenameExtension: "cube") ?? .data, .plainText, .data],
            allowsMultipleSelection: false
        ) { result in
            if case .success(let urls) = result, let url = urls.first {
                model.importLUT(from: url)
            }
        }
        .onChange(of: pickerItem) { item in
            guard let item = item else { return }
            Task {
                if let video = try? await item.loadTransferable(type: VideoFile.self) {
                    model.setVideo(video.url)
                } else {
                    model.message = "Das Video konnte nicht geladen werden."
                }
            }
        }
        .onChange(of: model.settingsKey) { _ in
            cubeToShare = nil
            model.refresh()
        }
    }
}
