import SwiftUI

@main
struct CCStudioApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
